# -*- coding: utf-8 -*-

"""
Package containing the global plugins.
"""
