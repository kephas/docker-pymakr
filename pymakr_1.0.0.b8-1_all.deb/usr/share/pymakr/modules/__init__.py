# -*- coding: utf-8 -*-

# Copyright (c) 2003 - 2016 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the eric6 Python IDE (version 6.1).

To get more information about eric6 please see the
<a href="http://eric-ide.python-projects.org/index.html">eric web site</a>.
"""
