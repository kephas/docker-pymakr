# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '../../src/Templates/TemplateHelpDialog.ui'
#
# Created: Mon Dec 19 14:49:21 2016
#      by: PyQt5 UI code generator 5.3.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_TemplateHelpDialog(object):
    def setupUi(self, TemplateHelpDialog):
        TemplateHelpDialog.setObjectName("TemplateHelpDialog")
        TemplateHelpDialog.resize(500, 600)
        TemplateHelpDialog.setSizeGripEnabled(True)
        self.verticalLayout = QtWidgets.QVBoxLayout(TemplateHelpDialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(TemplateHelpDialog)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.helpEdit = QtWidgets.QTextEdit(TemplateHelpDialog)
        self.helpEdit.setTabChangesFocus(True)
        self.helpEdit.setReadOnly(True)
        self.helpEdit.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.helpEdit.setObjectName("helpEdit")
        self.verticalLayout.addWidget(self.helpEdit)
        self.buttonBox = QtWidgets.QDialogButtonBox(TemplateHelpDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(TemplateHelpDialog)
        self.buttonBox.accepted.connect(TemplateHelpDialog.accept)
        self.buttonBox.rejected.connect(TemplateHelpDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(TemplateHelpDialog)

    def retranslateUi(self, TemplateHelpDialog):
        _translate = QtCore.QCoreApplication.translate
        TemplateHelpDialog.setWindowTitle(_translate("TemplateHelpDialog", "Template Help"))
        self.label.setText(_translate("TemplateHelpDialog", "<b>Template Help</b>"))

